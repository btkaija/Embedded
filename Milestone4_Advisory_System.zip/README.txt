This submission for Milestone #4 implements the framework to be used for integration. A simulator controls the decision making, and recording of new simulated data. Simply running RoverInterface.m class will be enough to see the GUI working. 

-Ben Kaija