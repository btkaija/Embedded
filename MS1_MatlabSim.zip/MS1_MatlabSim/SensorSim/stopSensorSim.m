% stop the SensorSim timer
stop(sensorSimTimer);

% close the SensorSim WiFly
fclose(ioSensorSimWiFly);

% clear all state
clear all;