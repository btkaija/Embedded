These are two class definitions, with the RoverInterface class containing an instance of the Simulator class. Creating an instance of the RoverInterface is enough to test and see the workings of the GUI. 

Developed using MATLAB R2014b. This is important because of dot notation used and only available in R2014b and later. 